#include<iostream>
#include<fstream>
#include<string.h>
using namespace std;
int flag=0;
class Railway
{
	public:
	int custID;
	char Cust_name[50];
	char Cust_address[100];
	char railwaydetails[100];
	char ticket[50];
	int quantity;
};

void create(Railway a[],int n)
{
	for(int i=0;i<n;i++)
	{
		ifstream myfile("railway_file.txt");
		if(myfile.is_open())
		{
			for(int i=0;i<n;i++)
			{
			myfile>>a[i].custID;
			myfile>>a[i].Cust_name;
			myfile>>a[i].Cust_address;
			myfile>>a[i].railwaydetails;
			myfile>>a[i].ticket;
			myfile>>a[i].quantity;
			}
		}
	}
}
void addRailwayRecord(Railway b)
{
	ofstream myfile1;
	myfile1.open("railway_file.txt",ios::app);
	char space=' ';
	myfile1<<b.custID;
	myfile1<<space;
	myfile1<<b.Cust_name;
	myfile1<<space;
	myfile1<<b.Cust_address;
	myfile1<<space;
	myfile1<<b.railwaydetails;
	myfile1<<space;
	myfile1<<b.ticket;
	myfile1<<space;
	myfile1<<b.quantity;
	myfile1<<"\n";
}
void print(Railway a[],int n)
{
	for(int i=0;i<n;i++)
	{
		cout<<"\n";
		cout<<a[i].custID;
		cout<<"\t";	
		cout<<a[i].Cust_name;
		cout<<"\t";
		cout<<a[i].Cust_address;
		cout<<"\t";	
		cout<<a[i].railwaydetails;
		cout<<"\t";	
		cout<<a[i].ticket;
		cout<<"\t";	
		cout<<a[i].quantity;
		cout<<"\n";	
	}
}
void printrecord(Railway a)
{
	cout<<"\nCustomer ID : "<<a.custID<<"\n";
	cout<<"\nCustomer name : "<<a.Cust_name<<"\n";
	cout<<"\nCustomer address : "<<a.Cust_address<<"\n";
	cout<<"\nRailway Details : "<<a.railwaydetails<<"\n";
	cout<<"\nRailway ticket : "<<a.ticket<<"\n";
	cout<<"\nQuantity : "<<a.quantity<<"\n";
}
int binary_search(Railway obj[],int size,int key)
{
	int first=0,last=size,mid;
	int position=-1;
	bool found=false;
	while(!found && first<=last)
	{
		mid=(first+last)/2;
		if(obj[mid].custID==key)
		{
			printrecord(obj[mid]);
			found =true;
			position=mid;
		}
		else if(obj[mid].custID>key)
			last=mid-1;
		else
			first=mid+1;
	}
	return position;
}
void swap(Railway* a, Railway* b)
{
    Railway s = *a;
    *a = *b;
    *b = s;
}
void bubblesort(Railway p[],int n)
{
	for(int i=0;i<(n-1);i++)
	{
		for(int j=0;j<n-i-1;j++)
		{
			if(p[j].custID > p[j+1].custID)
			{
				swap(&p[j],&p[j+1]);
			}
		}
	}
}
int main()
{
	Railway r[100];
	int n=7,res;
	int ch,ch0,ch2;
	int search;
	
	while(1)
	{
		cout<<"\n********Railway reservation system************";
		cout<<"\n1.	Admin";
		cout<<"\n2.	Customer";
		cout<<"\n3.	Exit";
		cout<<"\nEnter your choice : ";
		cin>>ch0;
		switch(ch0)
		{
			case 1:
				do
				{
					cout<<"\nAdmin side";
					cout<<"\n1.Load records from file";
					cout<<"\n2.Add a new customer";
					cout<<"\n3.Exit";
					cout<<"\n===============================";
					cout<<"\nEnter the choice:";
					cin>>ch;
					switch(ch)
					{
						case 1:
							cout<<"\nEnter the no. of records to load";
							cin>>n;
							create(r,n);
							bubblesort(r,n);
							cout<<"Sorted FIle items:";
							print(r,n);
							break;
						case 2:
							Railway b;
							cout<<"Enter Railway Journey details :\nCustID : ";
							cin>>b.custID;
							cout<<"\nCustomer Name : ";
							cin>>b.Cust_name;
							cout<<"\n Customer Address:";
							cin>>b.Cust_address;
							cout<<"\n Railway Details : ";
							cin>>b.railwaydetails;
							cout<<"\n Ticket : ";
							cin>>b.ticket;
							cout<<"\n Qunatity : ";
							cin>>b.quantity;
							addRailwayRecord(b);
							break;
						case 3:
							break;
						default:
							cout<<"Choice out of order!!!";
					}//end of switch case1
				}while(ch!=3);
			break;
			
			case 2:
				do
				{
					cout<<"\nCustomer side";
					cout<<"\n1.	Search for ticket details in system";
					cout<<"\n2.	Exit";
					cout<<"\nEnter the choice : ";
					cin>>ch;
					switch(ch)
					{
						case 1:
							cout<<"\nEnter the customer ID to be searched";
							cin>>search;
							res=binary_search(r,n-1,search);
							if(res==-1)
								cout<<"This customer doesnt exist.Please enter valid ID";
						break;

						case 2:
							break;
						default:
							cout<<"Choice out of order!!!";
					}//end of switch case1
				}while(ch!=2);
			break;
			
			case 3:
				cout<<"Exiting----\n";
				return 0;
		}//end of main switch
	}//end of while

	return 0;
}

