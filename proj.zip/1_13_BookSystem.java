import java.util.Comparator;
import java.util.Scanner;

class Book {
	int id;
	String b_name;
	int b_price;
	int b_quantity;
	String b_author;

	// Getters and setters for Product
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return b_name;
	}

	public void setName(String b_name) {
		this.b_name = b_name;
	}

	public int getPrice() {
		return b_price;
	}

	public void setPrice(int b_price) {
		this.b_price = b_price;
	}

	public int getQuantity() {
		return b_quantity;
	}

	public void setQuantity(int b_quantity) {
		this.b_quantity = b_quantity;
	}

	public String getAuthor() {
		return b_author;
	}

	public void setAuthor(String b_author) {
		this.b_author = b_author;
	}

}

public class BookSystem {

	static int count = 0;
	Book list[] = new Book[20]; // Product Storage
	int size = 0;

	int partition(int low, int high) {
		Book pivot = list[high];
		int i = (low - 1); // index of smaller element
		for (int j = low; j <= high - 1; j++) {
			// If current element is smaller than or
			// equal to pivot
			if (list[j].getName().compareTo(pivot.getName()) < 0) {
				i++;
				// swap i and j element
				Book temp = list[i];
				list[i] = list[j];
				list[j] = temp;
			}
		}

		// swap product i+1 and pivot

		Book temp = list[i + 1];
		list[i + 1] = list[high];
		list[high] = temp;
		return i + 1;
	}

	/* The main function that implements QuickSort() */
	void sort(int low, int high) {
		if (low < high) {
			int pi = partition(low, high);

			// Recursively sort elements before
			// partition and after partition
			sort(low, pi - 1);
			sort(pi + 1, high);
		}
	}

	public void binary_search(String pname) {
		int mid;
		int start = 0;
		int end = count;
		while (start < end) {
			mid = (start + end) / 2;
			Book p = list[mid];
			if (p.getName().equals(pname)) {
				System.out.println("Id\tName\tPrice\tQuantity\tAuthor\t");
				System.out.println("" + p.getId() + "\t" + p.getName() + "\t" + p.getPrice() + "\t" + p.getQuantity()
						+ "\t\t" + p.getAuthor());
				return;
			} else if (p.getName().compareTo(pname) < 0)
				start = mid;
			else
				end = mid;
		}
		System.out.println("Not found");
		return;
	}

	public static Comparator<Book> idComparator = new Comparator<Book>() {

		@Override
		public int compare(Book o1, Book o2) {
			// TODO Auto-generated method stub
			if (o1.b_name.compareTo(o2.b_name) < 0)
				return -1;
			else
				return 1;

		}
	};

	public void insert() {
		// inserting all elements
		Scanner sc = new Scanner(System.in);
		Book P = new Book();
		System.out.println("Enter Book name:");
		P.setName(sc.nextLine());
		System.out.println("Enter Price:");
		P.setPrice(Integer.parseInt(sc.nextLine()));
		System.out.println("Enter Quantity:");
		P.setQuantity(Integer.parseInt(sc.nextLine()));
		System.out.println("Enter Author name:");
		P.setAuthor(sc.nextLine());
		P.setId(count);

		list[count] = P;
		count++;
	}

	public void display() {
		// displaying all elements
		System.out.println("Id\tName\tPrice\tQuantity\tAuthor\t");
		for (int i = 0; i < count; i++) {
			Book p = list[i];
			System.out.println("" + p.getId() + "\t" + p.getName() + "\t" + p.getPrice() + "\t" + p.getQuantity()
					+ "\t\t" + p.getAuthor());
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BookSystem P = new BookSystem();
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("Library Mangement System\n1.Insert a book"
					+ "\n2.Search a book\n3.Display All Books\n4.Sort Books\nEnter Your choice:");
			int sw = Integer.parseInt(sc.nextLine());
			switch (sw) {
			case 1:
				P.insert();
				break;
			case 2:
				System.out.println("Enter Product to be search:");
				String pname = sc.nextLine();
				P.binary_search(pname);
				break;
			case 3:
				P.display();
				break;
			case 4:
				P.sort(0, P.count-1);
				System.out.println("Sorting performed.");
				break;
			default:

			}
		}

	}

}
