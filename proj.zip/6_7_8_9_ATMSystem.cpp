#include<iostream>
#include<omp.h>
using namespace std;
int k=0;
class atm
{
public:
    int userid;
    int cardno;
    string username;
    float balance;
    int type;
    int pin;
    void add_data()
    {
        cout<<" Please enter UserID of Account Number ?";
        cin>>userid;
        cout<<" Please enter CardNo (5digit) of Account Number ?";
        cin>>cardno;
        cout<<" Please enter Username of Account Number ?";
        cin>>username;
        cout<<" Please enter Type of Account Saving(0)/Current(1) ?";
        cin>>type;
        cout<<" Please enter PIN(4digit) of CARDNO ?";
        cin>>pin;
        cout<<" Please enter Balance of CARDNO ?";
        cin>>balance;

    }

    int get_userid()
    {
        return userid;
    }

    void withdraw(float val)
    {
        if(val<balance)
        {
            cout<<"Amount Withdran successful!..."<<endl;
            balance=balance-val;
            cout<<"Balance Available "<< balance;

        }
        else
        {
                cout<<"Insufficent Balance Please try again "<<endl;
                cout<<"Available BAL:"<< balance;
        }
    }

    void deposit(float val)
    {
        balance=balance+val;
    }


    float shwbal()
    {
        return balance;
    }

    void change_pin()
    {
        int pi;
        cout<<"Enter the old pin";
        if(pi==pin)
        {
                cout<<"Enter New Pin"<<endl;
                cin>>pi;
                pin=pi;
        }
    }

    int getpin()
    {
        return pin;
    }

};

int binarySearch(atm arr[], int l, int r, int x)        //array to be checked , l= lower limit , r = upper limit , x= item to be found
{
   if (r >= l)
   {
        int mid = l + (r - l)/2;

        // If the element is present at the middle
        // itself
        if (arr[mid].get_userid() == x)
            return mid;

        // If element is smaller than mid, then
        // it can only be present in left subarray
        if (arr[mid].get_userid() > x)
            return binarySearch(arr, l, mid-1, x);

        // Else the element can only be present
        // in right subarray
        return binarySearch(arr, mid+1, r, x);
   }

   // We reach here when element is not
   // present in array
   return -1;
}
void oddEvenSort(atm arr[], int n)
{
    bool isSorted = false; // Initially array is unsorted

    while (!isSorted)
    {
        isSorted = true;

        // Perform Bubble sort on odd indexed element
        for (int i=1; i<=n-2; i=i+2)
        {
            if (arr[i].get_userid() > arr[i+1].get_userid())
             {
                swap(arr[i], arr[i+1]);
                isSorted = false;
              }
        }

        // Perform Bubble sort on even indexed element
        for (int i=0; i<=n-2; i=i+2)
        {
            if (arr[i].get_userid() > arr[i+1].get_userid())
            {
                swap(arr[i], arr[i+1]);
                isSorted = false;
            }
        }
    }

    return;
}

int partition(atm arr[], int low_index, int high_index)
            {
            int i, j,  key;
            atm temp;
                key = arr[low_index].get_userid();
                i= low_index + 1;
                j= high_index;
              while(1)
                {
                    while(i < high_index && key >= arr[i].get_userid())
                        i++;
                    while(key < arr[j].get_userid())
                        j--;
                    if(i < j)
                        {
                        temp = arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;
                        }
                    else
                        {
                            temp= arr[low_index];
                            arr[low_index] = arr[j];
                            arr[j]= temp;
                            return(j);
                        }
                }
            };

void quicksort_om(atm arr[], int low_index, int high_index)
        {
            int j;

            if(low_index < high_index)
                {
                j = partition(arr, low_index, high_index);
                cout<<"Pivot element with index "<<j<<" has been found out by thread "<<k<<"\n";

                #pragma omp parallel sections
                    {
                        #pragma omp section
                        {
                            k=k+1;
                            quicksort_om(arr, low_index, j - 1);
                        }//end of section

                        #pragma omp section
                        {
                            k=k+1;
                            quicksort_om(arr, j + 1, high_index);
                        }//end of section

                    }// end of #pragma OMP parallel sections
                }
        };





int main()
{

    int cnt=0;
    atm obj[100];
    int ch0;
    while(1)
	{
		cout<<"\n==== ATM MAchine Simulation=====";
		cout<<"\nSelect one of the following :";
		cout<<"\n1.Add Account";
		cout<<"\n2.Withdraw";
		cout<<"\n3.Deposit";
		cout<<"\n4.Show Balance";
		cout<<"\n5.Sort accounts according to user ID";
		cout<<"\n6.Sort accounts according to user ID by openMP";
		cout<<"\n7.EXIT";
		cout<<"\n===============================";
		cout<<"\nEnter your choice:";
		cin>>ch0;

		switch(ch0)
		{
			case 1:
			    obj[cnt].add_data();
                cnt++;
                break;
            case 2:
                cout<<"Enter the Login Details :(userid/cardno)"<<endl;
                 {

                      int temp;
                        cout << "Enter User Id to be logged into ? "<<endl;
                        cin>>temp;
                            int loop=binarySearch(obj,0,cnt-1,temp);
                            if(loop==-1)
                            {
                               cout<< "Please Enter Valid User_ID"<<endl;
                            }
                            else
                            {
                                cout <<" Please enter PIN of the Card No. "<< obj[loop].cardno<<endl;
                                int pinned;
                                cin >>pinned;
                                if(obj[loop].pin==pinned)
                                {

                                float amt;
                                cout<<"Enter amount to be withdrawn form Card Account NO :" << obj[loop].cardno<<endl;
                                cin>>amt;
                                obj[loop].withdraw(amt);
                                }
                                else
                                {
                                    cout << "Invalid Pin "<<endl;
                                }

                            }
                }
                break;
            case 3:
                     cout<<"Enter the Login Details :(userid/cardno)"<<endl;
                 {

                      int temp;
                        cout << "Enter User Id to be logged into ? "<<endl;
                        cin>>temp;
                            int loop=binarySearch(obj,0,cnt-1,temp);
                            if(loop==-1)
                            {
                               cout<< "Please Enter Valid User_ID"<<endl;
                            }
                            else
                            {
                                cout <<" Please enter PIN of the Card No. "<< obj[loop].cardno<<endl;
                                 int pinned;
                                cin >>pinned;
                                if(obj[loop].pin==pinned)
                                {

                                float amt;
                                cout<<"Enter amount to be deposit to Card Account NO :" << obj[loop].cardno<<endl;
                                cin>>amt;
                                obj[loop].deposit(amt);
                                }
                                else
                                {
                                    cout << "Invalid Pin "<<endl;
                                }
                            }
                 }
                break;
            case 4:
                  cout<<"Enter the Login Details :(userid/cardno)"<<endl;
                 {

                      int temp;
                        cout << "Enter User Id to be logged into ? "<<endl;
                        cin>>temp;
                            int loop=binarySearch(obj,0,cnt-1,temp);
                            if(loop==-1)
                            {
                               cout<< "Please Enter Valid User_ID"<<endl;
                            }
                            else
                            {
                                cout <<" Please enter PIN of the Card No. "<< obj[loop].cardno<<endl;
                                int pinned;
                                cin >>pinned;
                                if(obj[loop].pin==pinned)
                                {

                                cout<<obj[loop].shwbal();
                                }
                                else
                                {
                                    cout << "Invalid Pin "<<endl;
                                }

                            }
                }
                break;

            case 5:
                oddEvenSort(obj,cnt);
                cout << "Accout details sorted as per userid+++++++++++++++++++++++++"<<endl;
                for(int i=0; i < cnt; i++)
                {
                    cout <<"User_Id:"<<obj[i].userid;
                    cout <<"Card_NO:"<<obj[i].cardno;
                    cout <<"Username:"<<obj[i].username;
                    cout <<"Type:";if(obj[i].type==0) cout<<"Savings "<<endl; else cout << "Current"<<endl;
                }
                break;
            case 6:
                quicksort_om(obj,0,cnt-1);
                cout << "Accout details sorted as per userid+++++++++++++++++++++++++"<<endl;
                for(int i=0; i < cnt; i++)
                {
                    cout <<"User_Id:"<<obj[i].userid;
                    cout <<"Card_NO:"<<obj[i].cardno;
                    cout <<"Username:"<<obj[i].username;
                    cout <<"Type:";if(obj[i].type==0) cout<<"Savings "<<endl; else cout << "Current"<<endl;
                }
                break;
            case 7:
                return 0;

		}
	}
    return 0;
}

