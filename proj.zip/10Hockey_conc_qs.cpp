#include<iostream>
using namespace std;

class Team
{
public:
	int rating;
	string team_name;
	string team_city;
	int score;
	Team ()
	{
		rating = 0;
		team_name="";
		team_city="";
		score=0;
	}
	
	Team(int rank,string t_name, string t_city, int points)
	{
		rating = rank;
		team_name=t_name;
		team_city=t_city;
		score=points;
	}

};
void swap(Team* a, Team* b)
{
    Team obj = *a;
    *a = *b;
    *b = obj;
}
int partition (Team arr[], int low, int high)
{
	int pivot = arr[high].rating;    // pivot
	int i = (low - 1);  // Index of smaller element

	for (int j = low; j <= high- 1; j++)
	{
	    // If current element is smaller than or
	    // equal to pivot
	    if (arr[j].rating <= pivot)
	    {
	    	i++;    // increment index of smaller element
		swap(&arr[i], &arr[j]);
	    }
	}
	
	swap(&arr[i + 1], &arr[high]);
	return (i + 1);
	
}

void quickSort(Team arr[], int low, int high)
{
	 int pi;
	 int k=0;
	 if (low < high)
	{
		pi=partition(arr, low, high);
		cout<<"Pivot element with index "<<pi<<" has been found out by thread "<<k<<"\n";
		#pragma omp parallel sections
		{
			#pragma omp section
			{
				k=k+1;
				quickSort(arr, low, pi - 1);
			}
			#pragma omp section
			{
				k=k+1;
				quickSort(arr, pi + 1, high);
			}
		}
		
	}
}

void displayTeams(Team t[],int count)
{
	cout<<"\nTeam Rank\tTeam Name\tTeam City\tTeam Score\n";
	for(int i=0;i<count;i++)
	{
		cout<<t[i].rating<<"\t";
		cout<<t[i].team_name<<"\t";
		cout<<t[i].team_city<<"\t";
		cout<<t[i].score<<"\t\n";
	}

}
int main()
{
	char c;
	Team t[100];
	t[0]=Team(11,"Golden_knights","Vegas",100);
	t[1]=Team(2,"Penguins","Pittsburgh",230);
	t[2]=Team(32,"Rangers","Newyork",300);
	int count=3;
	int choice;
	do
	{
		displayTeams(t,count);

		cout<<"\n--------------------------\nHockey League\n--------------------------";
		cout<<"\n1.Add new team record \n2.Sort and Display based on ratings\n";
		cin>>choice;
		switch(choice)
		{
		case 1:
			cout<<"\nEnter Team rank\n";
			cin>>t[count].rating;
			cout<<"\nEnter Team Name";
			cin>>t[count].team_name;
			cout<<"Enter Team city\n";
			cin>>t[count].team_city;
			cout<<"Score of Team\n";
			cin>>t[count].score;
			cout<<"Done adding new team\n";
			count++;
			break;

		case 2:
			quickSort(t,0,count-1);
			displayTeams(t,count);
			break;

		default:
			cout<<"Invalid choice\n";
			break;
		}
		cout<<"Continue?";
		cin>>c;
	}while(c=='y' || c=='Y');
	return 0;
}


/*
Output:
amol@AmolPC:~/Desktop/SDMT/10Hockey$ g++ Hockey_conc_qs.cpp -fopenmp
amol@AmolPC:~/Desktop/SDMT/10Hockey$ ./a.out

Team Rank	Team Name	Team City	Team Score
11	Golden_knights	Vegas	100	
2	Penguins	Pittsburgh	230	
32	Rangers	Newyork	300	

--------------------------
Hockey League
--------------------------
1.Add new team record 
2.Sort and Display based on ratings
1

Enter Team rank
1

Enter Team NamePune_warriors
Enter Team city
Pune
Score of Team
350
Done adding new team
Continue?y

Team Rank	Team Name	Team City	Team Score
11	Golden_knights	Vegas	100	
2	Penguins	Pittsburgh	230	
32	Rangers	Newyork	300	
1	Pune_warriors	Pune	350	

--------------------------
Hockey League
--------------------------
1.Add new team record 
2.Sort and Display based on ratings
2
Pivot element with index 0 has been found out by thread 0
Pivot element with index 2 has been found out by thread 0

Team Rank	Team Name	Team City	Team Score
1	Pune_warriors	Pune	350	
2	Penguins	Pittsburgh	230	
11	Golden_knights	Vegas	100	
32	Rangers	Newyork	300	
Continue?n
amol@AmolPC:~/Desktop/SDMT/10Hockey$ 


*/
