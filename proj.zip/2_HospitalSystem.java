import java.util.Comparator;
import java.util.Scanner;

class Patient {
	int id;
	String p_name;
	int p_age;
	String p_blood;
	String p_address;

	// Getters and setters for Product
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return p_name;
	}

	public void setName(String p_name) {
		this.p_name = p_name;
	}

	public int getAge() {
		return p_age;
	}

	public void setAge(int p_age) {
		this.p_age = p_age;
	}

	public String getBlood() {
		return p_blood;
	}

	public void setBlood(String p_blood) {
		this.p_blood = p_blood;
	}

	public String getAddress() {
		return p_address;
	}

	public void setAddress(String p_address) {
		this.p_address = p_address;
	}

}

public class HospitalSystem {

	static int count = 0;
	Patient list[] = new Patient[20]; // Product Storage
	int size = 0;

	int partition(int low, int high) {
		Patient pivot = list[high];
		int i = (low - 1); // index of smaller element
		for (int j = low; j <= high - 1; j++) {
			// If current element is smaller than or
			// equal to pivot
			if (list[j].getName().compareTo(pivot.getName()) < 0) {
				i++;
				// swap i and j element
				Patient temp = list[i];
				list[i] = list[j];
				list[j] = temp;
			}
		}

		// swap product i+1 and pivot

		Patient temp = list[i + 1];
		list[i + 1] = list[high];
		list[high] = temp;
		return i + 1;
	}

	/* The main function that implements QuickSort() */
	void sort(int low, int high) {
		if (low < high) {
			int pi = partition(low, high);

			// Recursively sort elements before
			// partition and after partition
			sort(low, pi - 1);
			sort(pi + 1, high);
		}
	}

	public void binary_search(String pname) {
		int mid;
		int start = 0;
		int end = count;
		while (start < end) {
			mid = (start + end) / 2;
			Patient p = list[mid];
			if (p.getName().equals(pname)) {
				System.out.println("Id\tName\tPrice\tQuantity\tAuthor\t");
				System.out.println("" + p.getId() + "\t" + p.getName() + "\t" + p.getAge() + "\t" + p.getBlood()
						+ "\t\t" + p.getAddress());
				return;
			} else if (p.getName().compareTo(pname) < 0)
				start = mid;
			else
				end = mid;
		}
		System.out.println("Not found");
		return;
	}

	public static Comparator<Patient> idComparator = new Comparator<Patient>() {

		@Override
		public int compare(Patient o1, Patient o2) {
			// TODO Auto-generated method stub
			if (o1.p_name.compareTo(o2.p_name) < 0)
				return -1;
			else
				return 1;

		}
	};

	public void insert() {
		// inserting all elements
		Scanner sc = new Scanner(System.in);
		Patient P = new Patient();
		System.out.println("Enter Patient name:");
		P.setName(sc.nextLine());
		System.out.println("Enter Age:");
		P.setAge(Integer.parseInt(sc.nextLine()));
		System.out.println("Enter Blood Group:");
		P.setBlood(sc.nextLine());
		System.out.println("Enter Address:");
		P.setAddress(sc.nextLine());
		P.setId(count);

		list[count] = P;
		count++;
	}

	public void display() {
		// displaying all elements
		
		for (int i = 0; i < count; i++) {
			Patient p = list[i];
			
			System.out.println("" + p.getId() + "\t" + p.getName() + "\t\t\t" + p.getAge() + "\t" + p.getBlood()
					+ "\t\t" + p.getAddress());
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HospitalSystem P = new HospitalSystem();
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("Hospital Mangement System\n1.Add a Patient"
					+ "\n2.Search a Patient\n3.Display All Patients\n4.Sort Patients\nEnter Your choice:");
			int sw = Integer.parseInt(sc.nextLine());
			switch (sw) {
			case 1:
				P.insert();
				break;
			case 2:
				System.out.println("Enter Product to be search:");
				String pname = sc.nextLine();
				P.binary_search(pname);
				break;
			case 3:
				P.display();
				break;
			case 4:
				P.sort(0, P.count - 1);
				System.out.println("Sorting performed.");
				break;
			default:

			}
		}

	}

}
